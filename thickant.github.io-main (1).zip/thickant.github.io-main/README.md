All of the Forward Winds Code that is currently being thought about being used for modding
